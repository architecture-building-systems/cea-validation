Shape files and images for all networks:

ToDo:
- .shp files some edges do not have predefined lengths, so tedious lengths are chosen by software. Change to standard value