# These files verify that the calculated mass flows fulfill the Kirchohff 1st and 2nd Laws

To run:
1. Run CEA Model
2. Change path to file
3. Run matlab verification file