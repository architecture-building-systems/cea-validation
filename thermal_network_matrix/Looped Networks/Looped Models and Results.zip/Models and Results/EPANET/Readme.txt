EPANET files are used to validate networks at chosen timesteps.
At these timesteps:

1. verify that pipe lengths and diameters match CEA
2. Input node mass flows at plant and consumers
3. Run EPANET analysis
4. View output table "Edges"