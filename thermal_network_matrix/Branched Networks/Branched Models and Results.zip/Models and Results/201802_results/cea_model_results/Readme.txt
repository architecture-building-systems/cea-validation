The results are simulted with extra_heat_transfer_coef (alpha) = 0. 
This is because there is no corresponding term in Simulink.